package com.qualitycontrol.suite;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
