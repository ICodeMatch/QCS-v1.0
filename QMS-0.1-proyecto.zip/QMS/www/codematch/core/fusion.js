export class EvidenceFusion{
  constructor(){this.items=[]}
  add(evidence){this.items.push(evidence);return evidence}
  clear(){this.items=[]}
  byProbe(name){return this.items.filter(item=>item.probe===name)}
  snapshot(){return {state:this.items.length?'CANDIDATO':'INCIERTO',confidence:null,confidenceKind:null,evidenceCount:this.items.length,provenance:this.items.map(({id,probe,status,source,createdAt})=>({id,probe,status,source,createdAt})),note:'Las evidencias se conservan independientes; la fusión no modifica sus resultados.'}}
}
