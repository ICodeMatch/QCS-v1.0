// Debe coincidir con la resolución de trabajo de aruco.js. Además, más abajo
// normalizamos las coordenadas por si este valor vuelve a cambiar.
async function loadPhoto(file,max=1100){
  const bmp=await createImageBitmap(file),scale=Math.min(1,max/Math.max(bmp.width,bmp.height));
  const canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(bmp.width*scale));canvas.height=Math.max(1,Math.round(bmp.height*scale));
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bmp,0,0,canvas.width,canvas.height);bmp.close();
  return{canvas,ctx};
}

function markerForCanvas(marker,w,h){
  const sourceW=marker?.sourceWidth||w,sourceH=marker?.sourceHeight||h;
  if(sourceW===w&&sourceH===h)return marker;
  const sx=w/sourceW,sy=h/sourceH,old=marker.imageToPlane;
  return{...marker,
    corners:marker.corners.map(p=>({x:p.x*sx,y:p.y*sy})),
    pixels:marker.pixels*(sx+sy)/2,
    mmPerPx:marker.mmPerPx/((sx+sy)/2),
    imageToPlane:old?[old[0]/sx,old[1]/sy,old[2],old[3]/sx,old[4]/sy,old[5],old[6]/sx,old[7]/sy]:null,
    sourceWidth:w,sourceHeight:h
  };
}

function excluded(x,y,markers){
  return markers.some(m=>{const xs=m.corners.map(p=>p.x),ys=m.corners.map(p=>p.y),side=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys)),pad=Math.max(20,side*1.15);return x>=Math.min(...xs)-pad&&x<=Math.max(...xs)+pad&&y>=Math.min(...ys)-pad&&y<=Math.max(...ys)+pad});
}

function sharpness(data,w,h){let total=0,count=0,step=Math.max(2,Math.floor(Math.min(w,h)/180));for(let y=step;y<h-step;y+=step)for(let x=step;x<w-step;x+=step){const i=(y*w+x)*4,l=(data[i]*30+data[i+1]*59+data[i+2]*11)/100,ix=(y*w+x+step)*4,iy=((y+step)*w+x)*4,lx=(data[ix]*30+data[ix+1]*59+data[ix+2]*11)/100,ly=(data[iy]*30+data[iy+1]*59+data[iy+2]*11)/100;total+=Math.abs(l-lx)+Math.abs(l-ly);count++}return count?Math.round(total/count):0}

function drawMarkers(ctx,markers,w){for(const m of markers){const xs=m.corners.map(p=>p.x),ys=m.corners.map(p=>p.y),side=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys)),pad=Math.max(20,side*1.15);ctx.save();ctx.fillStyle='rgba(155,70,210,.18)';ctx.strokeStyle='#a83ddd';ctx.lineWidth=Math.max(3,w/260);ctx.setLineDash([10,7]);ctx.fillRect(Math.min(...xs)-pad,Math.min(...ys)-pad,Math.max(...xs)-Math.min(...xs)+pad*2,Math.max(...ys)-Math.min(...ys)+pad*2);ctx.strokeRect(Math.min(...xs)-pad,Math.min(...ys)-pad,Math.max(...xs)-Math.min(...xs)+pad*2,Math.max(...ys)-Math.min(...ys)+pad*2);ctx.setLineDash([]);ctx.strokeStyle='#00d084';ctx.lineWidth=Math.max(3,w/240);ctx.beginPath();m.corners.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.restore()}}

function preprocess(data,w,h,mode){if(mode==='original')return;const copy=new Uint8ClampedArray(data);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,r=copy[i],g=copy[i+1],b=copy[i+2],l=(r*30+g*59+b*11)/100;let v=l;if(mode==='grayscale')v=l;else if(mode==='gamma')v=255*Math.pow(l/255,.72);else if(mode==='highlights')v=255*(1-Math.pow(1-l/255,1.45));else if(mode==='denoise'){let sum=0,n=0;for(let yy=Math.max(0,y-1);yy<=Math.min(h-1,y+1);yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(w-1,x+1);xx++){const j=(yy*w+xx)*4;sum+=(copy[j]*30+copy[j+1]*59+copy[j+2]*11)/100;n++}v=sum/n}else continue;if(mode==='grayscale'||mode==='denoise'){data[i]=data[i+1]=data[i+2]=v}else{const ratio=v/Math.max(1,l);data[i]=Math.min(255,r*ratio);data[i+1]=Math.min(255,g*ratio);data[i+2]=Math.min(255,b*ratio)}}}

function perimeterBackground(data,w,h){const samples=[],step=Math.max(1,Math.floor(Math.min(w,h)/100));for(let x=0;x<w;x+=step){samples.push([x,0],[x,h-1])}for(let y=step;y<h-1;y+=step){samples.push([0,y],[w-1,y])}const channel=k=>{const values=samples.map(([x,y])=>data[(y*w+x)*4+k]).sort((a,b)=>a-b);return Math.round(values[(values.length/2)|0]||0)};return{r:channel(0),g:channel(1),b:channel(2),source:'mediana del perímetro'}}

function drawMask(ctx,c,w,h){
  const chosen=new Uint8Array(w*h);for(const p of c.pixels)chosen[p]=1;
  const layer=document.createElement('canvas');layer.width=w;layer.height=h;const layerCtx=layer.getContext('2d'),overlay=layerCtx.createImageData(w,h);
  for(const p of c.pixels){const x=p%w,y=(p/w)|0,boundary=x<1||y<1||x>=w-1||y>=h-1||!chosen[p-1]||!chosen[p+1]||!chosen[p-w]||!chosen[p+w],i=p*4;if(boundary){overlay.data[i]=255;overlay.data[i+1]=210;overlay.data[i+2]=40;overlay.data[i+3]=230}else{overlay.data[i]=0;overlay.data[i+1]=210;overlay.data[i+2]=160;overlay.data[i+3]=52}}
  layerCtx.putImageData(overlay,0,0);ctx.drawImage(layer,0,0);
}

function extractRawContour(c,w,h){const mask=new Uint8Array(w*h);for(const p of c.pixels)mask[p]=1;const edges=new Map(),add=(ax,ay,bx,by)=>{const key=`${ax},${ay}`;(edges.get(key)||edges.set(key,[]).get(key)).push({x:bx,y:by})};for(const p of c.pixels){const x=p%w,y=(p/w)|0;if(y===0||!mask[p-w])add(x,y,x+1,y);if(x===w-1||!mask[p+1])add(x+1,y,x+1,y+1);if(y===h-1||!mask[p+w])add(x+1,y+1,x,y+1);if(x===0||!mask[p-1])add(x,y+1,x,y)}const loops=[];while(edges.size){const first=edges.keys().next().value,[sx,sy]=first.split(',').map(Number),loop=[{x:sx,y:sy}];let key=first,guard=0;while(edges.has(key)&&guard++<w*h*2){const list=edges.get(key),next=list.pop();if(!list.length)edges.delete(key);loop.push(next);key=`${next.x},${next.y}`;if(key===first)break}if(loop.length>4)loops.push(loop)}return loops.sort((a,b)=>b.length-a.length)[0]||[]}
function pointSegmentDistance(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/Math.max(1e-9,dx*dx+dy*dy))),x=a.x+t*dx,y=a.y+t*dy;return Math.hypot(p.x-x,p.y-y)}
function rdp(points,epsilon){if(points.length<3)return points;let max=0,index=0;for(let i=1;i<points.length-1;i++){const d=pointSegmentDistance(points[i],points[0],points.at(-1));if(d>max){max=d;index=i}}if(max<=epsilon)return[points[0],points.at(-1)];const left=rdp(points.slice(0,index+1),epsilon),right=rdp(points.slice(index),epsilon);return[...left.slice(0,-1),...right]}
function simplifyClosed(points,epsilon){if(points.length<5)return points;const base=points[0];let split=1,max=0;for(let i=1;i<points.length-1;i++){const d=Math.hypot(points[i].x-base.x,points[i].y-base.y);if(d>max){max=d;split=i}}const a=rdp(points.slice(0,split+1),epsilon),b=rdp([...points.slice(split),base],epsilon);return[...a.slice(0,-1),...b.slice(0,-1)]}
function drawContourLine(ctx,points,color,width,dash=[]){if(points.length<2)return;ctx.save();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.restore()}
function contourFidelity(raw,simplified,w,h){if(!raw.length||!simplified.length)return 0;let worst=0;const step=Math.max(1,Math.floor(raw.length/600));for(let i=0;i<raw.length;i+=step){let best=Infinity;for(let j=0;j<simplified.length;j++)best=Math.min(best,pointSegmentDistance(raw[i],simplified[j],simplified[(j+1)%simplified.length]));worst=Math.max(worst,best)}const normalized=worst/Math.max(1,Math.hypot(w,h)),vertexPenalty=simplified.length<=4&&raw.length>30?.45:1;return Math.max(0,Math.min(1,1-normalized*28))*vertexPenalty}
function diagnosticCanvases(source,c,raw,simplified,final,w,h){const clone=()=>{const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,0,0);return out},mask=document.createElement('canvas');mask.width=w;mask.height=h;const mctx=mask.getContext('2d'),image=mctx.createImageData(w,h);for(const p of c.pixels){const i=p*4;image.data[i]=image.data[i+1]=image.data[i+2]=255;image.data[i+3]=255}for(let i=3;i<image.data.length;i+=4)if(!image.data[i])image.data[i]=255;mctx.putImageData(image,0,0);const rawCanvas=clone(),simpleCanvas=clone(),finalCanvas=clone();drawContourLine(rawCanvas.getContext('2d'),raw,'#ffd228',Math.max(2,w/500));drawContourLine(simpleCanvas.getContext('2d'),simplified,'#b84dff',Math.max(3,w/360));drawContourLine(finalCanvas.getContext('2d'),final,'#ff6923',Math.max(4,w/280));return{mask,raw:rawCanvas,simplified:simpleCanvas,final:finalCanvas}}

function orientedDimensions(c,w){
  let mx=0,my=0;for(const p of c.pixels){mx+=p%w;my+=(p/w)|0}mx/=c.pixels.length;my/=c.pixels.length;
  let xx=0,yy=0,xy=0;for(const p of c.pixels){const dx=p%w-mx,dy=((p/w)|0)-my;xx+=dx*dx;yy+=dy*dy;xy+=dx*dy}
  const angle=.5*Math.atan2(2*xy,xx-yy),ux=Math.cos(angle),uy=Math.sin(angle),vx=-uy,vy=ux;let minU=Infinity,maxU=-Infinity,minV=Infinity,maxV=-Infinity;
  for(const p of c.pixels){const dx=p%w-mx,dy=((p/w)|0)-my,u=dx*ux+dy*uy,v=dx*vx+dy*vy;minU=Math.min(minU,u);maxU=Math.max(maxU,u);minV=Math.min(minV,v);maxV=Math.max(maxV,v)}
  const corners=[[minU,minV],[maxU,minV],[maxU,maxV],[minU,maxV]].map(([u,v])=>({x:mx+u*ux+v*vx,y:my+u*uy+v*vy}));
  return{longPx:Math.max(maxU-minU,maxV-minV),shortPx:Math.min(maxU-minU,maxV-minV),corners};
}

function projectToPlane(h,x,y){const d=h[6]*x+h[7]*y+1;if(Math.abs(d)<1e-8)return null;return{x:(h[0]*x+h[1]*y+h[2])/d,y:(h[3]*x+h[4]*y+h[5])/d}}

// Mide en el plano del ArUco. Así una foto oblicua no usa una única escala de píxel.
function planeDimensions(c,w,marker){
  if(!marker?.imageToPlane)return null;const points=[],step=Math.max(1,Math.floor(c.pixels.length/18000));
  for(let i=0;i<c.pixels.length;i+=step){const p=c.pixels[i],q=projectToPlane(marker.imageToPlane,p%w,(p/w)|0);if(q&&Number.isFinite(q.x)&&Number.isFinite(q.y))points.push(q)}
  if(points.length<20)return null;let mx=0,my=0;for(const p of points){mx+=p.x;my+=p.y}mx/=points.length;my/=points.length;let xx=0,yy=0,xy=0;
  for(const p of points){const dx=p.x-mx,dy=p.y-my;xx+=dx*dx;yy+=dy*dy;xy+=dx*dy}const angle=.5*Math.atan2(2*xy,xx-yy),ux=Math.cos(angle),uy=Math.sin(angle),vx=-uy,vy=ux;let minU=Infinity,maxU=-Infinity,minV=Infinity,maxV=-Infinity;
  for(const p of points){const dx=p.x-mx,dy=p.y-my,u=dx*ux+dy*uy,v=dx*vx+dy*vy;minU=Math.min(minU,u);maxU=Math.max(maxU,u);minV=Math.min(minV,v);maxV=Math.max(maxV,v)}return{longMm:Math.max(maxU-minU,maxV-minV),shortMm:Math.min(maxU-minU,maxV-minV)};
}

function drawOrientedBox(ctx,box,w){ctx.save();ctx.strokeStyle='#ff6923';ctx.lineWidth=Math.max(3,w/280);ctx.beginPath();box.corners.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.restore()}

function refinedBoxByGradient(data,w,h,box){
  const [p0,p1,,p3]=box.corners,ul=Math.hypot(p1.x-p0.x,p1.y-p0.y),vl=Math.hypot(p3.x-p0.x,p3.y-p0.y);
  if(ul<20||vl<20)return box;
  const u={x:(p1.x-p0.x)/ul,y:(p1.y-p0.y)/ul},v={x:(p3.x-p0.x)/vl,y:(p3.y-p0.y)/vl},radius=Math.max(5,Math.min(22,Math.round(Math.min(ul,vl)*.12))),gap=Math.max(2,Math.round(Math.min(w,h)/320));
  const pixel=(x,y)=>{x=Math.max(0,Math.min(w-1,Math.round(x)));y=Math.max(0,Math.min(h-1,Math.round(y)));const i=(y*w+x)*4;return[data[i],data[i+1],data[i+2]]};
  const strength=(origin,tangent,normal,length,offset)=>{let sum=0,n=0;for(let i=1;i<15;i++){const t=length*i/15,x=origin.x+tangent.x*t+normal.x*offset,y=origin.y+tangent.y*t+normal.y*offset,a=pixel(x-normal.x*gap,y-normal.y*gap),b=pixel(x+normal.x*gap,y+normal.y*gap);sum+=Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2]);n++}return sum/Math.max(1,n)};
  const best=(origin,tangent,normal,length)=>{let chosen=0,score=-1;for(let o=-radius;o<=radius;o++){const s=strength(origin,tangent,normal,length,o);if(s>score){score=s;chosen=o}}return{offset:chosen,score}};
  const minV=best(p0,u,v,ul),maxV=best(p3,u,v,ul),minU=best(p0,v,u,vl),maxU=best(p1,v,u,vl);
  const reliable=[minV,maxV,minU,maxU].every(x=>x.score>24);if(!reliable)return box;
  const base={x:p0.x+u.x*minU.offset+v.x*minV.offset,y:p0.y+u.y*minU.offset+v.y*minV.offset},du=ul+maxU.offset-minU.offset,dv=vl+maxV.offset-minV.offset;
  const corners=[base,{x:base.x+u.x*du,y:base.y+u.y*du},{x:base.x+u.x*du+v.x*dv,y:base.y+u.y*du+v.y*dv},{x:base.x+v.x*dv,y:base.y+v.y*dv}];
  if(corners.some(p=>p.x<0||p.y<0||p.x>=w||p.y>=h)||du<15||dv<15)return box;
  return{...box,longPx:Math.max(du,dv),shortPx:Math.min(du,dv),corners,gradientAdjusted:true,gradientScores:[minV.score,maxV.score,minU.score,maxU.score]};
}

function planeBoxDimensions(box,marker){if(!marker?.imageToPlane)return null;const p=box.corners.map(q=>projectToPlane(marker.imageToPlane,q.x,q.y));if(p.some(q=>!q))return null;const sides=p.map((q,i)=>Math.hypot(q.x-p[(i+1)%4].x,q.y-p[(i+1)%4].y)),a=(sides[0]+sides[2])/2,b=(sides[1]+sides[3])/2;return{longMm:Math.max(a,b),shortMm:Math.min(a,b)}}

function cellDistance(a,b){const dl=Math.abs(a.l-b.l),dr=a.r-b.r,dg=a.g-b.g,db=a.b-b.b,dc=Math.sqrt(dr*dr+dg*dg+db*db),dt=Math.abs(a.t-b.t);return dc*.68+dl*.42+dt*.72}

function surfaceCandidates(data,w,h,markers,seed=null,sensitivity=0){
  const cell=Math.max(5,Math.round(Math.min(w,h)/115)),cw=Math.ceil(w/cell),ch=Math.ceil(h/cell),cells=new Array(cw*ch);
  for(let cy=0;cy<ch;cy++)for(let cx=0;cx<cw;cx++){
    const x0=cx*cell,y0=cy*cell,x1=Math.min(w,x0+cell),y1=Math.min(h,y0+cell);let r=0,g=0,b=0,t=0,n=0,blocked=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){if(excluded(x,y,markers)){blocked++;continue}const i=(y*w+x)*4;r+=data[i];g+=data[i+1];b+=data[i+2];if(x+1<x1){const j=i+4;t+=(Math.abs(data[i]-data[j])+Math.abs(data[i+1]-data[j+1])+Math.abs(data[i+2]-data[j+2]))/3}if(y+1<y1){const j=i+w*4;t+=(Math.abs(data[i]-data[j])+Math.abs(data[i+1]-data[j+1])+Math.abs(data[i+2]-data[j+2]))/3}n++}
    if(!n||blocked>(x1-x0)*(y1-y0)*.35){cells[cy*cw+cx]={blocked:true,cx,cy};continue}
    r/=n;g/=n;b/=n;cells[cy*cw+cx]={cx,cy,r,g,b,l:(r*30+g*59+b*11)/100,t:t/Math.max(1,n*2),n,x0,y0,x1,y1,blocked:false};
  }
  const labels=new Int32Array(cells.length);labels.fill(-1);const regions=[];let label=0;
  const seedCell=seed?Math.max(0,Math.min(ch-1,Math.floor(seed.y*h/cell)))*cw+Math.max(0,Math.min(cw-1,Math.floor(seed.x*w/cell))):-1;
  const starts=seed?[seedCell]:cells.map((_,i)=>i);
  for(const start of starts){if(start<0||labels[start]>=0||cells[start]?.blocked)continue;const anchor=cells[start],queue=[start],members=[];labels[start]=label;let head=0,sr=0,sg=0,sb=0,sl=0,st=0;
    while(head<queue.length){const q=queue[head++],a=cells[q];members.push(q);sr+=a.r;sg+=a.g;sb+=a.b;sl+=a.l;st+=a.t;const mean={r:sr/members.length,g:sg/members.length,b:sb/members.length,l:sl/members.length,t:st/members.length};
      const ns=[];if(a.cx>0)ns.push(q-1);if(a.cx<cw-1)ns.push(q+1);if(a.cy>0)ns.push(q-cw);if(a.cy<ch-1)ns.push(q+cw);
      for(const ni of ns){const next=cells[ni];if(labels[ni]>=0||!next||next.blocked)continue;const local=cellDistance(a,next),regional=cellDistance(mean,next),anchored=cellDistance(anchor,next),limit=(seed?52:43)+sensitivity*4;
        // El vecino evita saltos bruscos; el ancla fija impide encadenar poco a poco
        // la pieza con una sombra o un reflejo de tono gradualmente distinto.
        if(local<limit*.72&&regional<limit&&anchored<limit*1.05){labels[ni]=label;queue.push(ni)}}
    }
    regions.push({members,label});label++;if(seed)break;
  }
  const candidates=[];
  for(const region of regions){if(region.members.length<4)continue;let minX=w,maxX=0,minY=h,maxY=0,boundaryTotal=0,boundaryN=0,edge=false;const pixels=[],owned=new Set(region.members);
    for(const ci of region.members){const a=cells[ci];minX=Math.min(minX,a.x0);maxX=Math.max(maxX,a.x1-1);minY=Math.min(minY,a.y0);maxY=Math.max(maxY,a.y1-1);if(a.x0===0||a.y0===0||a.x1===w||a.y1===h)edge=true;for(let y=a.y0;y<a.y1;y++)for(let x=a.x0;x<a.x1;x++)if(!excluded(x,y,markers))pixels.push(y*w+x);const ns=[];if(a.cx>0)ns.push(ci-1);if(a.cx<cw-1)ns.push(ci+1);if(a.cy>0)ns.push(ci-cw);if(a.cy<ch-1)ns.push(ci+cw);for(const ni of ns)if(!owned.has(ni)&&cells[ni]&&!cells[ni].blocked){boundaryTotal+=cellDistance(a,cells[ni]);boundaryN++}}
    const bw=maxX-minX+1,bh=maxY-minY+1,area=bw*bh,fill=pixels.length/Math.max(1,area),ratio=Math.max(bw,bh)/Math.max(1,Math.min(bw,bh)),imageShare=pixels.length/(w*h),boundary=boundaryTotal/Math.max(1,boundaryN);
    if(pixels.length<350||bw<20||bh<20||ratio>5.5||imageShare>.55)continue;
    const compact=Math.min(1,fill/.72),sizeScore=Math.min(1,pixels.length/(w*h*.045)),boundaryScore=Math.min(1,boundary/55),edgePenalty=edge?.18:1,score=(compact*.42+boundaryScore*.38+sizeScore*.2)*edgePenalty;
    candidates.push({minX,maxX,minY,maxY,bw,bh,area,pixels,fill,edge,boundary,score,imageShare,mode:seed?'toque conectado':'regiones'});
  }
  return candidates.sort((a,b)=>b.score-a.score);
}

// Segunda evidencia independiente: estima el fondo sólo desde el perímetro y
// avanza hacia dentro. No sustituye a surfaceCandidates; se usa para comprobar
// si ambos recorridos delimitan aproximadamente la misma pieza.
function outsideInCandidates(data,w,h,markers){
  const cell=Math.max(6,Math.round(Math.min(w,h)/105)),cw=Math.ceil(w/cell),ch=Math.ceil(h/cell),cells=[];
  for(let cy=0;cy<ch;cy++)for(let cx=0;cx<cw;cx++){
    const x0=cx*cell,y0=cy*cell,x1=Math.min(w,x0+cell),y1=Math.min(h,y0+cell);let r=0,g=0,b=0,n=0,blocked=0;
    for(let y=y0;y<y1;y+=2)for(let x=x0;x<x1;x+=2){if(excluded(x,y,markers)){blocked++;continue}const i=(y*w+x)*4;r+=data[i];g+=data[i+1];b+=data[i+2];n++}
    cells.push({cx,cy,x0,y0,x1,y1,r:r/Math.max(1,n),g:g/Math.max(1,n),b:b/Math.max(1,n),blocked:!n||blocked>n*.45});
  }
  const border=cells.filter(c=>!c.blocked&&(c.cx===0||c.cy===0||c.cx===cw-1||c.cy===ch-1));
  if(border.length<8)return[];
  const median=key=>{const v=border.map(c=>c[key]).sort((a,b)=>a-b);return v[(v.length/2)|0]},bg={r:median('r'),g:median('g'),b:median('b')};
  const dist=c=>Math.hypot(c.r-bg.r,c.g-bg.g,c.b-bg.b),seen=new Uint8Array(cells.length),queue=[];
  for(let i=0;i<cells.length;i++){const c=cells[i];if(!c.blocked&&(c.cx===0||c.cy===0||c.cx===cw-1||c.cy===ch-1)&&dist(c)<58){seen[i]=1;queue.push(i)}}
  for(let head=0;head<queue.length;head++){const q=queue[head],c=cells[q],ns=[];if(c.cx)ns.push(q-1);if(c.cx<cw-1)ns.push(q+1);if(c.cy)ns.push(q-cw);if(c.cy<ch-1)ns.push(q+cw);for(const ni of ns){const n=cells[ni];if(!seen[ni]&&!n.blocked&&dist(n)<58){seen[ni]=1;queue.push(ni)}}}
  const labels=new Uint8Array(cells.length),out=[];
  for(let start=0;start<cells.length;start++){if(seen[start]||labels[start]||cells[start].blocked)continue;const q=[start],members=[];labels[start]=1;for(let head=0;head<q.length;head++){const i=q[head],c=cells[i];members.push(c);const ns=[];if(c.cx)ns.push(i-1);if(c.cx<cw-1)ns.push(i+1);if(c.cy)ns.push(i-cw);if(c.cy<ch-1)ns.push(i+cw);for(const ni of ns)if(!seen[ni]&&!labels[ni]&&!cells[ni].blocked){labels[ni]=1;q.push(ni)}}
    if(members.length<6)continue;const minX=Math.min(...members.map(c=>c.x0)),maxX=Math.max(...members.map(c=>c.x1-1)),minY=Math.min(...members.map(c=>c.y0)),maxY=Math.max(...members.map(c=>c.y1-1)),bw=maxX-minX+1,bh=maxY-minY+1,share=members.reduce((s,c)=>s+(c.x1-c.x0)*(c.y1-c.y0),0)/(w*h),edge=minX===0||minY===0||maxX===w-1||maxY===h-1;
    if(edge||bw<20||bh<20||share>.55||Math.max(bw,bh)/Math.max(1,Math.min(bw,bh))>5.5)continue;const pixels=[];for(const c of members)for(let y=c.y0;y<c.y1;y++)for(let x=c.x0;x<c.x1;x++)if(!excluded(x,y,markers))pixels.push(y*w+x);const fill=pixels.length/Math.max(1,bw*bh),score=Math.min(.9,.42+Math.min(.28,fill*.25)+Math.min(.2,share*2));out.push({minX,maxX,minY,maxY,bw,bh,area:bw*bh,pixels,fill,edge:false,boundary:0,score,imageShare:share,mode:'fondo desde perímetro'});
  }
  return out.sort((a,b)=>b.score-a.score);
}

function boxIoU(a,b){const x=Math.max(0,Math.min(a.maxX,b.maxX)-Math.max(a.minX,b.minX)+1),y=Math.max(0,Math.min(a.maxY,b.maxY)-Math.max(a.minY,b.minY)+1),inter=x*y;return inter/Math.max(1,a.area+b.area-inter)}

export async function analyzeContour(file,markers,mmPerPx,preferred=0,seed=null,sensitivity=0,maxSize=1100,normalization='original'){
  const{canvas,ctx}=await loadPhoto(file,maxSize),w=canvas.width,h=canvas.height,image=ctx.getImageData(0,0,w,h),data=image.data;
  const backgroundEstimate=perimeterBackground(data,w,h);preprocess(data,w,h,normalization);if(normalization!=='original')ctx.putImageData(image,0,0);
  markers=markers.map(marker=>markerForCanvas(marker,w,h));
  const inside=surfaceCandidates(data,w,h,markers,seed,sensitivity),outside=seed?[]:outsideInCandidates(data,w,h,markers),agreement=!seed&&inside.length&&outside.length?outside.map(o=>({o,i:inside.reduce((best,c)=>boxIoU(c,o)>boxIoU(best,o)?c:best,inside[0])})).sort((a,b)=>boxIoU(b.i,b.o)-boxIoU(a.i,a.o))[0]:null,agreedIoU=agreement?boxIoU(agreement.i,agreement.o):0,list=agreedIoU>=.55?[{...agreement.i,mode:'interior + fondo desde perímetro',outsideAgreement:agreedIoU},...inside.filter(c=>c!==agreement.i)]:inside,focus=sharpness(data,w,h);drawMarkers(ctx,markers,w);
  if(seed){const sx=Math.max(0,Math.min(w-1,Math.round(seed.x*w))),sy=Math.max(0,Math.min(h-1,Math.round(seed.y*h)));ctx.strokeStyle='#fff';ctx.fillStyle='#ffb000';ctx.lineWidth=Math.max(3,w/260);ctx.beginPath();ctx.arc(sx,sy,Math.max(7,w/85),0,Math.PI*2);ctx.fill();ctx.stroke()}
  const index=list.length?Math.max(0,Math.min(preferred,list.length-1)):0,c=list[index]||null;
  if(!c)return{canvas,contour:null,candidateCount:0,candidateIndex:0,sharpness:focus,interactive:!!seed,rejectedReason:'sin región conectada',backgroundEstimate,normalization};
  const second=list[1],ambiguity=!seed&&second&&second.score>c.score*.9,plausible=c.score>=.56&&!c.edge&&c.fill>=.28&&c.imageShare<.42;
  if(!plausible||ambiguity)return{canvas,contour:null,candidateCount:list.length,candidateIndex:index,sharpness:focus,interactive:!!seed,rejectedReason:ambiguity?'varias regiones parecidas':'región no fiable',backgroundEstimate,normalization};
  const diagnosticSource=document.createElement('canvas');diagnosticSource.width=w;diagnosticSource.height=h;diagnosticSource.getContext('2d').drawImage(canvas,0,0);drawMask(ctx,c,w,h);const rawContour=extractRawContour(c,w,h),epsilon=Math.max(1.2,Math.hypot(w,h)*.0035),simplifiedContour=simplifyClosed(rawContour,epsilon),finalContour=simplifiedContour,fidelity=contourFidelity(rawContour,finalContour,w,h);drawContourLine(ctx,rawContour,'#ffd228',Math.max(2,w/500));drawContourLine(ctx,simplifiedContour,'#b84dff',Math.max(3,w/360),[9,6]);drawContourLine(ctx,finalContour,'#ff6923',Math.max(4,w/280));const diagnostics=diagnosticCanvases(diagnosticSource,c,rawContour,simplifiedContour,finalContour,w,h),coarseBox=orientedDimensions(c,w),box=refinedBoxByGradient(data,w,h,coarseBox);const metric=Number.isFinite(mmPerPx)&&mmPerPx>0,marker=markers.find(m=>m.imageToPlane),plane=metric?planeDimensions(c,w,marker):null,longMm=plane?.longMm??box.longPx*(metric?mmPerPx:1),shortMm=plane?.shortMm??box.shortPx*(metric?mmPerPx:1),confidence=Math.round(Math.max(12,Math.min(88,c.score*100*fidelity)));
  ctx.fillStyle='#082c38';ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.font=`bold ${Math.max(18,w/30)}px system-ui`;const label=metric?`${longMm.toFixed(1)} × ${shortMm.toFixed(1)} mm · ${confidence}% heurístico`:`Contorno experimental · ${confidence}% heurístico`;
  ctx.strokeText(label,Math.max(8,c.minX),Math.max(28,c.minY-10));ctx.fillText(label,Math.max(8,c.minX),Math.max(28,c.minY-10));
  return{canvas,contour:{...c,pixels:undefined,length:longMm,width:shortMm,units:metric?'mm':'px',confidence,confidenceKind:'heuristica-experimental',mode:`${c.mode} + contorno conservado${plane?' + perspectiva':''}`,outsideAgreement:c.outsideAgreement??null,gradientAdjusted:!!box.gradientAdjusted,gradientScores:box.gradientScores||null,orientedCorners:box.corners,rawContour,rawVertexCount:rawContour.length,simplifiedContour,simplifiedVertexCount:simplifiedContour.length,finalContour,contourFidelity:fidelity,holes:[]},diagnosticCanvases:diagnostics,candidateCount:list.length,candidateIndex:index,sharpness:focus,interactive:!!seed,backgroundEstimate,normalization};
}
