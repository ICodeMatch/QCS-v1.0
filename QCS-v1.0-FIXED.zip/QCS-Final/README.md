# Quality Control Suite v1.0

Aplicación móvil Android con 5 módulos de gestión de calidad industrial:
- **CodeMatch v2.9.0** - Identificación de piezas
- **Non-Conformities** - Gestión de no conformidades
- **Homologation** - Aprobaciones de piezas
- **Quality Reports** - Análisis Cpk/SPC
- **Quality Projects** - Gestión de acciones correctivas

## ⚡ Inicio rápido

### Requisitos (IMPORTANTE)

**❌ EVITAR:** JDK 8, JDK 17+
**✅ USAR:** JDK 11 específicamente

#### Windows
- **Java JDK 11** → https://www.oracle.com/java/technologies/downloads/#java11
  - Verificar: `java -version` debe mostrar `11.x.x`
- **Android Studio** → https://developer.android.com/studio (instala SDK automáticamente)
- **Node.js 16+** → https://nodejs.org

#### macOS
```bash
brew install openjdk@11
brew install node
```
Descargar Android Studio: https://developer.android.com/studio

#### Linux
```bash
sudo apt-get install openjdk-11-jdk nodejs
```
Descargar Android Studio: https://developer.android.com/studio

### Configuración (una sola vez)

**1. Crear `android/local.properties`** en la raíz del proyecto:

```properties
# Windows
sdk.dir=C:\Users\[TU_USUARIO]\AppData\Local\Android\Sdk

# macOS
sdk.dir=/Users/[TU_USUARIO]/Library/Android/Sdk

# Linux
sdk.dir=$HOME/Android/Sdk
```

**2. Verificar Android SDK en Android Studio:**
- Abre Android Studio
- Settings → Android SDK
- Verifica que API 34+ esté instalado

### Compilación

```bash
cd QCS-Final

# Instalar dependencias
npm install

# Instalar Capacitor CLI (primera vez)
npm install -g @capacitor/cli

# Sincronizar código web con Android
npx cap sync android

# Compilar APK
cd android
./gradlew assembleRelease
```

**En Windows:** Usar `gradlew.bat assembleRelease` en lugar de `gradlew`

### APK generado
```
android/app/build/outputs/apk/release/app-release.apk
```

## 🔧 Troubleshooting

### "java.net.SocketException: Network is unreachable"
```bash
# Verifica conexión a internet
ping google.com

# Limpia caché de Gradle
rm -rf ~/.gradle/wrapper/dists/

# Reintenta compilación
./gradlew assembleRelease
```

### "Android SDK not found"
1. Abre Android Studio
2. Va a Settings → Android SDK
3. Anota la ruta del SDK (ej: `/Users/user/Library/Android/Sdk`)
4. Crea `android/local.properties` con: `sdk.dir=/ruta/del/sdk`
5. Reintenta

### "JAVA_HOME not set"
```bash
# Linux/Mac
export JAVA_HOME=/path/to/jdk-11

# Windows
set JAVA_HOME=C:\Program Files\Java\jdk-11
```

### Primera compilación toma mucho tiempo
✅ **Normal:** Descarga gradle-8.2.1, SDK build-tools, etc. (5-15 minutos)

## 📱 Instalar en OPPO A94 5G

```bash
# USB + ADB
adb install android/app/build/outputs/apk/release/app-release.apk

# O manualmente:
# 1. Conectar OPPO por USB
# 2. Copiar APK a carpeta Descargas
# 3. Abrir Archivos → Descargas → [APK] → Instalar
```

## ✅ Verificación

```bash
# Comprobar que existe
ls -lh android/app/build/outputs/apk/release/app-release.apk

# Generar SHA256
sha256sum android/app/build/outputs/apk/release/app-release.apk

# Verificar validez
file android/app/build/outputs/apk/release/app-release.apk
# Debe mostrar: "Zip archive data"
```

## 📋 Información técnica

- **App ID:** com.qualitycontrol.suite
- **Versión:** 1.0.0
- **minSdk:** 22 (Android 5.0+)
- **targetSdk:** 34 (Android 14)
- **Gradle:** 8.2.1
- **Capacitor:** 6.2.2
- **Tipo:** HTML5 + WebView (sin código nativo)
