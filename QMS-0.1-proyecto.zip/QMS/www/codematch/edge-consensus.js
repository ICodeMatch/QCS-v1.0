// Laboratorio reversible: consenso de bordes entre iluminaciones sintéticas.
// No es un modelo de IA ni una probabilidad de que el borde sea físico.

const clamp=v=>Math.max(0,Math.min(255,v));

async function loadGray(file,maxSize){
  const bitmap=await createImageBitmap(file),scale=Math.min(1,maxSize/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  const image=ctx.getImageData(0,0,canvas.width,canvas.height),gray=new Uint8Array(canvas.width*canvas.height);
  for(let p=0,i=0;p<gray.length;p++,i+=4)gray[p]=(image.data[i]*30+image.data[i+1]*59+image.data[i+2]*11)/100;
  return{canvas,ctx,image,gray,w:canvas.width,h:canvas.height};
}

function markerMask(markers,w,h){
  const mask=new Uint8Array(w*h);
  for(const marker of markers||[]){
    const sx=w/(marker.sourceWidth||w),sy=h/(marker.sourceHeight||h),xs=marker.corners.map(p=>p.x*sx),ys=marker.corners.map(p=>p.y*sy),side=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys)),pad=Math.max(12,side*1.15),x0=Math.max(0,Math.floor(Math.min(...xs)-pad)),x1=Math.min(w-1,Math.ceil(Math.max(...xs)+pad)),y0=Math.max(0,Math.floor(Math.min(...ys)-pad)),y1=Math.min(h-1,Math.ceil(Math.max(...ys)+pad));
    for(let y=y0;y<=y1;y++)mask.fill(1,y*w+x0,y*w+x1+1);
  }
  return mask;
}

function blur3(src,w,h){const out=new Uint8Array(src.length);for(let y=0;y<h;y++)for(let x=0;x<w;x++){let sum=0,n=0;for(let yy=Math.max(0,y-1);yy<=Math.min(h-1,y+1);yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(w-1,x+1);xx++){sum+=src[yy*w+xx];n++}out[y*w+x]=sum/n}return out}
function adjust(src,fn){const out=new Uint8Array(src.length);for(let i=0;i<src.length;i++)out[i]=clamp(fn(src[i],i));return out}
function equalize(src){const hist=new Uint32Array(256);for(const v of src)hist[v]++;const out=new Uint8Array(src.length);let acc=0;const lut=new Uint8Array(256);for(let i=0;i<256;i++){acc+=hist[i];lut[i]=255*acc/src.length}for(let i=0;i<src.length;i++)out[i]=lut[src[i]];return out}
function localNormalize(src,w,h){const smooth=blur3(blur3(src,w,h),w,h);return adjust(src,(v,i)=>128+(v-smooth[i])*1.7)}
function claheApprox(src,w,h,tile=48,clipFactor=2){
  const out=new Uint8Array(src.length),tw=Math.ceil(w/tile),th=Math.ceil(h/tile),maps=[];
  for(let ty=0;ty<th;ty++)for(let tx=0;tx<tw;tx++){
    const x0=tx*tile,x1=Math.min(w,x0+tile),y0=ty*tile,y1=Math.min(h,y0+tile),count=(x1-x0)*(y1-y0),hist=new Uint32Array(256),limit=Math.max(1,Math.round(count/256*clipFactor));
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)hist[src[y*w+x]]++;
    let excess=0;for(let i=0;i<256;i++)if(hist[i]>limit){excess+=hist[i]-limit;hist[i]=limit}const add=Math.floor(excess/256),rest=excess%256;for(let i=0;i<256;i++)hist[i]+=add+(i<rest?1:0);
    const lut=new Uint8Array(256);let acc=0;for(let i=0;i<256;i++){acc+=hist[i];lut[i]=255*acc/Math.max(1,count)}maps[ty*tw+tx]=lut;
  }
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const tx=Math.min(tw-1,Math.floor(x/tile)),ty=Math.min(th-1,Math.floor(y/tile));out[y*w+x]=maps[ty*tw+tx][src[y*w+x]]}return out;
}

function downsample2(src,w,h){const nw=Math.max(2,Math.round(w/2)),nh=Math.max(2,Math.round(h/2)),out=new Uint8Array(nw*nh);for(let y=0;y<nh;y++)for(let x=0;x<nw;x++){const sx=Math.min(w-2,x*2),sy=Math.min(h-2,y*2);out[y*nw+x]=(src[sy*w+sx]+src[sy*w+sx+1]+src[(sy+1)*w+sx]+src[(sy+1)*w+sx+1])/4}return{data:out,w:nw,h:nh}}
function percentile(values,q){const sample=[];const step=Math.max(1,Math.floor(values.length/24000));for(let i=0;i<values.length;i+=step)if(values[i])sample.push(values[i]);sample.sort((a,b)=>a-b);return sample.length?sample[Math.min(sample.length-1,Math.floor(sample.length*q))]:255}
function sobel(src,w,h,mask){
  const smooth=blur3(src,w,h),magnitude=new Uint16Array(w*h);
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const p=y*w+x;if(mask?.[p])continue;const a=p-w-1,b=p-w,c=p-w+1,d=p-1,f=p+1,g=p+w-1,i=p+w,j=p+w+1,gx=-smooth[a]+smooth[c]-2*smooth[d]+2*smooth[f]-smooth[g]+smooth[j],gy=-smooth[a]-2*smooth[b]-smooth[c]+smooth[g]+2*smooth[i]+smooth[j];magnitude[p]=Math.min(1023,Math.hypot(gx,gy))}
  const threshold=Math.max(28,percentile(magnitude,.84)),edges=new Uint8Array(w*h);let count=0;for(let p=0;p<edges.length;p++)if(!mask?.[p]&&magnitude[p]>=threshold){edges[p]=1;count++}return{edges,count,threshold};
}
function expandVotes(votes,edges,sourceW,sourceH,targetW,targetH,scale=1){for(let p=0;p<edges.length;p++)if(edges[p]){const x=p%sourceW,y=(p/sourceW)|0,x0=Math.round(x*scale),y0=Math.round(y*scale),radius=scale===1?1:2;for(let yy=Math.max(0,y0-radius);yy<=Math.min(targetH-1,y0+radius);yy++)for(let xx=Math.max(0,x0-radius);xx<=Math.min(targetW-1,x0+radius);xx++)votes[yy*targetW+xx]++}}
function edgeCanvas(edges,w,h,color=[255,255,255]){const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d'),image=ctx.createImageData(w,h);for(let p=0;p<edges.length;p++){const i=p*4;if(edges[p]){image.data[i]=color[0];image.data[i+1]=color[1];image.data[i+2]=color[2]}image.data[i+3]=255}ctx.putImageData(image,0,0);return c}

export async function analyzeEdgeConsensus(file,markers,{maxSize=640}={}){
  const started=performance.now(),source=await loadGray(file,maxSize),{gray,w,h,canvas}=source,mask=markerMask(markers,w,h),baseVariants=[
    ['Original',gray],['Exposición −',adjust(gray,v=>v*.72)],['Exposición +',adjust(gray,v=>v*1.28)],['Contraste',adjust(gray,v=>128+(v-128)*1.45)],['Gamma 0,72',adjust(gray,v=>255*Math.pow(v/255,.72))],['Gamma 1,35',adjust(gray,v=>255*Math.pow(v/255,1.35))],['Altas luces reducidas',adjust(gray,v=>255*(1-Math.pow(1-v/255,1.45)))],['Grises ecualizados',equalize(gray)],['Normalización local',localNormalize(gray,w,h)],['CLAHE aproximado',claheApprox(gray,w,h)],['Denoise',blur3(gray,w,h)]
  ],votes=new Uint16Array(w*h),diagnostics=[];
  for(const [label,data]of baseVariants){const result=sobel(data,w,h,mask);expandVotes(votes,result.edges,w,h,w,h,1);diagnostics.push({label:`100 % · ${label}`,edgeCount:result.count,threshold:result.threshold,canvas:edgeCanvas(result.edges,w,h)})}
  const half=downsample2(gray,w,h),halfMask=downsample2(mask,w,h).data,halfVariants=[['Original',half.data],['Contraste',adjust(half.data,v=>128+(v-128)*1.45)],['Gamma',adjust(half.data,v=>255*Math.pow(v/255,.78))],['CLAHE aproximado',claheApprox(half.data,half.w,half.h,32)],['Denoise',blur3(half.data,half.w,half.h)]];
  for(const [label,data]of halfVariants){const result=sobel(data,half.w,half.h,halfMask);expandVotes(votes,result.edges,half.w,half.h,w,h,2);diagnostics.push({label:`50 % · ${label}`,edgeCount:result.count,threshold:result.threshold,canvas:edgeCanvas(result.edges,half.w,half.h)})}
  const total=diagnostics.length,required=Math.max(4,Math.ceil(total*.38)),stable=new Uint8Array(w*h);let stablePixels=0,voteTotal=0;for(let p=0;p<stable.length;p++)if(!mask[p]&&votes[p]>=required){stable[p]=1;stablePixels++;voteTotal+=votes[p]}
  const overlay=document.createElement('canvas');overlay.width=w;overlay.height=h;const ctx=overlay.getContext('2d');ctx.drawImage(canvas,0,0);const image=ctx.getImageData(0,0,w,h);for(let p=0;p<stable.length;p++){const i=p*4;if(mask[p]){image.data[i]=170;image.data[i+1]=70;image.data[i+2]=210;image.data[i+3]=210}else if(stable[p]){const strength=(votes[p]-required)/Math.max(1,total-required);image.data[i]=255;image.data[i+1]=Math.round(210-110*strength);image.data[i+2]=25;image.data[i+3]=255}}ctx.putImageData(image,0,0);
  return{canvas:overlay,consensusCanvas:edgeCanvas(stable,w,h,[255,145,20]),stableEdge:stable,width:w,height:h,diagnostics,stats:{width:w,height:h,variants:total,requiredVotes:required,stablePixels,stableShare:stablePixels/(w*h),meanStableVotes:stablePixels?voteTotal/stablePixels:0,elapsedMs:Math.round(performance.now()-started),kind:'consenso heurístico experimental'},markerMask:mask};
}
