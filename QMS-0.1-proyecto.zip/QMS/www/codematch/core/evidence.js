export const EvidenceStatus=Object.freeze({CONFIRMED:'CONFIRMADO',CANDIDATE:'CANDIDATO',UNCERTAIN:'INCIERTO',NOT_OBSERVED:'NO_OBSERVADO'});

export function createEvidence({probe,status=EvidenceStatus.UNCERTAIN,result=null,confidence=null,confidenceKind=null,region=null,source='local',notes='',frameIds=[]}={}){
  if(!probe)throw new Error('La evidencia necesita una sonda de origen');
  if(confidence!=null&&(confidence<0||confidence>1))throw new Error('Confianza fuera de rango');
  return Object.freeze({id:crypto.randomUUID(),probe,status,result,confidence,confidenceKind:confidence==null?null:(confidenceKind||'heuristica-experimental'),region,source,notes,frameIds:[...frameIds],createdAt:new Date().toISOString()});
}

export function confidenceLabel(e){
  if(e.confidence==null)return 'sin estimar';
  const value=Math.round(e.confidence*100);
  return e.confidenceKind==='calibrada'?`${value}% calibrada`:`${value}% · heurística experimental`;
}
