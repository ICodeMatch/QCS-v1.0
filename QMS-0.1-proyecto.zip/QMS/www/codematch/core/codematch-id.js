export const CODEMATCH_ID_SCHEMA='0.1-experimental';

export function recordToCandidate(record){
  return {schema:CODEMATCH_ID_SCHEMA,code:String(record.code||''),name:record.name||'',dimensions:{developed:{length:record.developedLength??null,width:record.developedWidth??null,height:null},folded:{length:record.foldedLength??null,width:record.foldedWidth??null,height:record.foldedHeight??null}},outerContour:null,faces:[],faceRelations:[],folds:[],features:{holes:[],windows:[],punches:[]},hand:null,descriptorQuality:{state:'INCIERTO',notes:'Adaptado del catálogo actual; sin descriptor geométrico enriquecido'},sourceRecord:record};
}
