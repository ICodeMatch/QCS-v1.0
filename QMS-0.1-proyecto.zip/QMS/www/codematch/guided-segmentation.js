// Laboratorio reversible: segmentación multisemilla de pieza/fondo.
// No modifica candidatos ni produce probabilidades calibradas.

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

async function loadImage(file,maxSize){
  const bitmap=await createImageBitmap(file),scale=Math.min(1,maxSize/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  return{canvas,ctx,image:ctx.getImageData(0,0,canvas.width,canvas.height),w:canvas.width,h:canvas.height};
}

function markerMask(markers,w,h){
  const mask=new Uint8Array(w*h);
  for(const marker of markers||[]){
    const sx=w/(marker.sourceWidth||w),sy=h/(marker.sourceHeight||h),xs=marker.corners.map(p=>p.x*sx),ys=marker.corners.map(p=>p.y*sy),side=Math.max(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys)),pad=Math.max(10,side*.7),x0=clamp(Math.floor(Math.min(...xs)-pad),0,w-1),x1=clamp(Math.ceil(Math.max(...xs)+pad),0,w-1),y0=clamp(Math.floor(Math.min(...ys)-pad),0,h-1),y1=clamp(Math.ceil(Math.max(...ys)+pad),0,h-1);
    for(let y=y0;y<=y1;y++)mask.fill(1,y*w+x0,y*w+x1+1);
  }
  return mask;
}

function cellFeatures(image,w,h,cell){
  const cw=Math.ceil(w/cell),ch=Math.ceil(h/cell),items=[];
  for(let cy=0;cy<ch;cy++)for(let cx=0;cx<cw;cx++){
    let r=0,g=0,b=0,n=0;const x1=Math.min(w,(cx+1)*cell),y1=Math.min(h,(cy+1)*cell);
    for(let y=cy*cell;y<y1;y+=2)for(let x=cx*cell;x<x1;x+=2){const i=(y*w+x)*4;r+=image.data[i];g+=image.data[i+1];b+=image.data[i+2];n++}
    items.push({r:r/n,g:g/n,b:b/n,cx,cy});
  }
  return{items,cw,ch};
}

const colorDistance=(a,b)=>Math.hypot(a.r-b.r,a.g-b.g,a.b-b.b);
function seedIndex(seed,w,h,cell,cw,ch){const x=clamp(Math.floor(seed.x*w/cell),0,cw-1),y=clamp(Math.floor(seed.y*h/cell),0,ch-1);return y*cw+x}

class MinHeap{
  constructor(){this.a=[]}
  push(item){const a=this.a;a.push(item);let i=a.length-1;while(i){const p=(i-1)>>1;if(a[p][0]<=item[0])break;a[i]=a[p];i=p}a[i]=item}
  pop(){const a=this.a,top=a[0],last=a.pop();if(a.length){let i=0;a[0]=last;while(true){let l=i*2+1,r=l+1,n=i;if(l<a.length&&a[l][0]<a[n][0])n=l;if(r<a.length&&a[r][0]<a[n][0])n=r;if(n===i)break;[a[i],a[n]]=[a[n],a[i]];i=n}}return top}
  get length(){return this.a.length}
}

function geodesic(items,cw,ch,sources,prototypes,blocked){
  const dist=new Float32Array(items.length);dist.fill(Infinity);const heap=new MinHeap();
  for(const source of sources){if(blocked[source])continue;dist[source]=0;heap.push([0,source])}
  while(heap.length){const [cost,i]=heap.pop();if(cost!==dist[i])continue;const x=i%cw,y=(i/cw)|0,ns=[];if(x)ns.push(i-1);if(x<cw-1)ns.push(i+1);if(y)ns.push(i-cw);if(y<ch-1)ns.push(i+cw);
    for(const j of ns){if(blocked[j])continue;const local=colorDistance(items[i],items[j]),model=Math.min(...prototypes.map(p=>colorDistance(items[j],p))),step=1+local*.55+model*.08,next=cost+step;if(next<dist[j]){dist[j]=next;heap.push([next,j])}}
  }
  return dist;
}

function cleanMask(mask,w,h){
  const out=mask.slice();for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){let n=0;for(let yy=y-1;yy<=y+1;yy++)for(let xx=x-1;xx<=x+1;xx++)n+=mask[yy*w+xx];out[y*w+x]=n>=5?1:0}return out;
}

function boundary(mask,w,h){const edge=new Uint8Array(mask.length);for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const p=y*w+x;if(mask[p]&&(!mask[p-1]||!mask[p+1]||!mask[p-w]||!mask[p+w]))edge[p]=1}return edge}
function maskCanvas(mask,w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d'),im=ctx.createImageData(w,h);for(let p=0;p<mask.length;p++){const i=p*4;if(mask[p]){im.data[i]=92;im.data[i+1]=225;im.data[i+2]=204;im.data[i+3]=220}}ctx.putImageData(im,0,0);return c}

export async function analyzeGuidedSegmentation(file,markers,pieceSeeds,backgroundSeeds,{maxSize=720,cell=8}={}){
  if(!pieceSeeds?.length)throw new Error('Añade al menos un punto de pieza.');
  const started=performance.now(),source=await loadImage(file,maxSize),{canvas,image,w,h}=source,excluded=markerMask(markers,w,h),{items,cw,ch}=cellFeatures(image,w,h,cell),blocked=new Uint8Array(items.length);
  for(let cy=0;cy<ch;cy++)for(let cx=0;cx<cw;cx++){const px=clamp(Math.round((cx+.5)*cell),0,w-1),py=clamp(Math.round((cy+.5)*cell),0,h-1);if(excluded[py*w+px])blocked[cy*cw+cx]=1}
  const fg=[...new Set(pieceSeeds.map(s=>seedIndex(s,w,h,cell,cw,ch)))],explicitBg=[...new Set((backgroundSeeds||[]).map(s=>seedIndex(s,w,h,cell,cw,ch)))],perimeter=[];
  for(let x=0;x<cw;x++){perimeter.push(x,(ch-1)*cw+x)}for(let y=1;y<ch-1;y++){perimeter.push(y*cw,y*cw+cw-1)}
  const bg=[...new Set([...explicitBg,...perimeter])].filter(i=>!fg.includes(i)&&!blocked[i]),fgProto=fg.map(i=>items[i]),bgProto=(explicitBg.length?explicitBg:bg.filter((_,i)=>i%Math.max(1,Math.floor(bg.length/24))===0)).map(i=>items[i]);
  const fgDist=geodesic(items,cw,ch,fg,fgProto,blocked),bgDist=geodesic(items,cw,ch,bg,bgProto,blocked),cellMask=new Uint8Array(items.length);
  for(let i=0;i<items.length;i++)if(!blocked[i]&&fgDist[i]<bgDist[i]*1.04)cellMask[i]=1;for(const i of fg)cellMask[i]=1;for(const i of explicitBg)cellMask[i]=0;
  const pixelMask=new Uint8Array(w*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const ci=Math.min(ch-1,(y/cell)|0)*cw+Math.min(cw-1,(x/cell)|0);if(cellMask[ci]&&!excluded[y*w+x])pixelMask[y*w+x]=1}
  const cleaned=cleanMask(pixelMask,w,h);for(const seed of pieceSeeds){const sx=Math.round(seed.x*w),sy=Math.round(seed.y*h);for(let y=Math.max(0,sy-5);y<=Math.min(h-1,sy+5);y++)for(let x=Math.max(0,sx-5);x<=Math.min(w-1,sx+5);x++)cleaned[y*w+x]=1}
  const edge=boundary(cleaned,w,h),overlay=document.createElement('canvas');overlay.width=w;overlay.height=h;const ctx=overlay.getContext('2d');ctx.drawImage(canvas,0,0);const out=ctx.getImageData(0,0,w,h);let area=0,edgePixels=0;
  for(let p=0;p<cleaned.length;p++){const i=p*4;if(excluded[p]){out.data[i]=170;out.data[i+1]=70;out.data[i+2]=210;out.data[i+3]=220}else if(edge[p]){out.data[i]=255;out.data[i+1]=105;out.data[i+2]=35;out.data[i+3]=255;edgePixels++}else if(cleaned[p]){out.data[i]=Math.round(out.data[i]*.55+65);out.data[i+1]=Math.round(out.data[i+1]*.55+120);out.data[i+2]=Math.round(out.data[i+2]*.55+105);area++}}
  ctx.putImageData(out,0,0);for(const [seeds,color]of[[pieceSeeds,'#ff9f1c'],[backgroundSeeds||[],'#168aad']])for(const seed of seeds){ctx.beginPath();ctx.arc(seed.x*w,seed.y*h,Math.max(6,w/90),0,Math.PI*2);ctx.fillStyle=color;ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=Math.max(2,w/320);ctx.stroke()}
  const areaShare=area/(w*h),plausible=areaShare>=.005&&areaShare<=.72&&edgePixels>0;
  return{canvas:overlay,maskCanvas:maskCanvas(cleaned,w,h),mask:cleaned,edge,stats:{width:w,height:h,pieceSeeds:pieceSeeds.length,backgroundSeeds:(backgroundSeeds||[]).length,arucoExcluded:(markers||[]).length,areaPixels:area,areaShare,edgePixels,elapsedMs:Math.round(performance.now()-started),state:plausible?'CANDIDATO':'INCIERTO',kind:'segmentación guiada experimental'}};
}
