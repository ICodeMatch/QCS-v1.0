import {createEvidence,EvidenceStatus} from './evidence.js';

export class ProbeRegistry{
  #probes=new Map();
  register(name,probe){if(this.#probes.has(name))throw new Error(`Sonda duplicada: ${name}`);this.#probes.set(name,probe);return this}
  has(name){return this.#probes.has(name)}
  list(){return [...this.#probes.entries()].map(([name,p])=>({name,implemented:p.implemented!==false,description:p.description||''}))}
  async run(name,context){const probe=this.#probes.get(name);if(!probe)throw new Error(`Sonda desconocida: ${name}`);return probe.run(context)}
}

export function createDefaultRegistry(){
  const registry=new ProbeRegistry();
  registry.register('dimensions',{description:'Medidas introducidas o estimadas',async run({length,width,source='operator'}){const known=Number.isFinite(length)||Number.isFinite(width);return createEvidence({probe:'dimensions',status:known?EvidenceStatus.CANDIDATE:EvidenceStatus.UNCERTAIN,result:{length:length??null,width:width??null},source,notes:known?'Medida disponible; requiere origen y tolerancia para confirmar':'Sin medida concluyente'})}});
  for(const name of ['contour','holes','window','punch','fold','fold_direction','multiview','depth'])registry.register(name,{implemented:false,description:'Contrato preparado; implementación pendiente o adaptador experimental',async run({region=null}={}){return createEvidence({probe:name,status:EvidenceStatus.UNCERTAIN,region,result:null,notes:'Sonda preparada arquitectónicamente; no ejecutada en esta versión'})}});
  return registry;
}
