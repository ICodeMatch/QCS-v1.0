# QMS 0.1 — primera versión funcional

Aplicación principal de gestión de calidad, con CodeMatch como apartado.

## Incluido
- Menú QMS y distintivo Android propio.
- Código web recuperado de CodeMatch v2.9.0: ArUco, contorno, segmentación, laboratorio, importación Excel y PIN del módulo. No se ha validado de nuevo la visión ni su integración en Android.
- No conformidades: registro, causa, acción, responsable, fecha y verificación.
- Homologaciones: piezas/proveedores, requisitos, estado y resultado.
- Informes: mediciones, límites, media, desviación muestral, Pp/Ppk y unidades fuera de límites. Cp/Cpk opcionales con desviación agrupada dentro de subgrupos y media de esas mediciones. Introducir una línea por subgrupo, con al menos dos subgrupos de dos mediciones. Cm/Cmk con una serie de máquina separada y desviación muestral. No incluye cartas SPC ni valida las condiciones del estudio.
- Proyectos: objetivos, responsable, estado, fecha y notas de acciones.
- Guardar/editar/eliminar registros; búsqueda; exportación CSV; copia/restauración JSON de los cuatro módulos QMS.

## Datos y límites
Los cuatro módulos nuevos guardan datos en localStorage. CodeMatch conserva su IndexedDB y exportación propias. No se migran automáticamente datos de otra APK. El catálogo real de 18.000 referencias no está incluido: hay que importarlo en CodeMatch. La copia QMS no incluye CodeMatch.
Sin usuarios, control de permisos, sincronización, adjuntos ni trazabilidad de cambios. El PIN heredado protege sólo la pantalla CodeMatch, no QMS ni cifra datos. No usar todavía como registro oficial.

## Compilar en GitHub
El workflow se entrega en .github/workflows/build.yml. No se ha ejecutado ni se ha generado una APK en este entorno.

Opción desde móvil:
1. Subir QMS-0.1-proyecto.zip a la raíz del repositorio.
2. Crear o sustituir .github/workflows/build.yml con el contenido del workflow que viene dentro de ese ZIP.
3. Evitar otros ZIP cuyo nombre empiece por QMS en la raíz. El workflow exige uno solo cuando no existe package.json.
4. Actions → QMS Android prueba → Run workflow.
5. Descargar el artefacto QMS-0.1-APK-PRUEBA al terminar.

Si el repositorio ya tiene package.json en raíz, el workflow compila esa raíz: sustituir el proyecto antiguo por éste o utilizar un repositorio limpio.

La compilación genera una APK debug firmada automáticamente para pruebas, no una entrega release. El nombre del paquete es com.qualitycontrol.suite. No desinstalar aplicaciones previas sin exportar sus datos. Una firma distinta puede impedir actualizar una APK anterior.

## Verificación realizada
- Sintaxis JavaScript y YAML.
- Cálculo con muestra 9.8, 10, 10.2: media 10, s 0.2, Ppk 1.6667.
- Rechazo de datos numéricos inválidos y límites incorrectos; dispersión cero no genera un índice engañoso.
- Guardado, modificación y eliminación de registros en prueba con almacenamiento simulado.
- No se pudo ejecutar revisión visual: falta Chromium y el entorno bloquea el servidor local.
- Pendiente: ejecución de Actions, instalación OPPO, cámara/galería, PIN, importación Excel, persistencia real y exportación de archivos en Android.
