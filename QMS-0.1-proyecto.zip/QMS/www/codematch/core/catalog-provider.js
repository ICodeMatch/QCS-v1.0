export class CatalogProvider{constructor({id,label,load,isSynthetic=false}){this.id=id;this.label=label;this.load=load;this.isSynthetic=isSynthetic}}
export const localCatalogProvider=records=>new CatalogProvider({id:'local-indexeddb',label:'Catálogo local importado',load:async()=>records()});
export const syntheticCatalogProvider=()=>new CatalogProvider({id:'synthetic-demo-v1',label:'DATOS FICTICIOS DE PRUEBA',isSynthetic:true,load:async()=>[
  {code:'PRUEBA-001',name:'Pieza rectangular de prueba',developedLength:170,developedWidth:90},
  {code:'PRUEBA-002',name:'Pieza estrecha de prueba',developedLength:170,developedWidth:45},
  {code:'PRUEBA-003',name:'Pieza cuadrada de prueba',developedLength:100,developedWidth:100},
  {code:'PRUEBA-004',name:'Pieza larga con extremo A',developedLength:500,developedWidth:80},
  {code:'PRUEBA-005',name:'Pieza larga con extremo B',developedLength:500,developedWidth:80},
  {code:'PRUEBA-006',name:'Pieza plegada de prueba',developedLength:220,developedWidth:60,foldedLength:180,foldedWidth:60,foldedHeight:20}
]});
