const materials=['Acero inoxidable','Acero galvanizado','Aluminio','Acero'];
const families=['Soporte lateral','Bandeja plegada','Cubierta técnica','Escuadra de montaje','Perfil de refuerzo'];

export function demoCatalog(){
  const rows=[];
  for(let i=1;i<=40;i++){
    const group=Math.floor((i-1)/4),variant=(i-1)%4;
    const length=420+group*47+(variant===3?4:0),width=180+(group%5)*27,height=28+(group%4)*7+(variant===2?-4:0);
    rows.push({
      code:`CM-DEMO-${String(i).padStart(3,'0')}`,
      name:`${families[group%families.length]} · demostración`,
      developedLength:length+18,developedWidth:width+12,
      foldedLength:length,foldedWidth:width,foldedHeight:height,
      thickness:variant===3?1.5:variant===2?1.2:1,
      material:materials[(group+variant)%materials.length],
      hand:variant%2?'Izquierda / 31':'Derecha / 30',revision:`Rev.${String(2+(group+variant)%7).padStart(2,'0')}`,
      revisionState:variant===2?'Pendiente':variant===3?'Obsoleta':'Vigente',
      punches:(group+variant)%6,holes:(group*2+variant)%8,windows:variant===3?1:0,
      features:[variant===0?'pestaña corta':variant===1?'pestaña larga':variant===2?'pliegue exterior':'ventana lateral'],
      extraMeasures:{ala:22+(group%4)*3},dataSource:'Demostración',validation:'Pendiente',
      notes:'REFERENCIA FICTICIA. Uso exclusivo para demostración y pruebas.',
      source:'demo',catalogSource:'demo',isDemo:true,sourceUpdatedAt:'2026-09-21T00:00:00.000Z'
    });
  }
  return rows;
}
