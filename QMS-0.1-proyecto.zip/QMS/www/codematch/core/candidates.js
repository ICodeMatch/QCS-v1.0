import {recordToCandidate} from './codematch-id.js';

const finite=v=>Number.isFinite(Number(v));
export function rankCandidates(records,observation={}){
  const ql=finite(observation.length)?Number(observation.length):null,qw=finite(observation.width)?Number(observation.width):null,text=String(observation.text||'').trim().toLowerCase();
  return records.map(record=>{
    const candidate=recordToCandidate(record),l=Number(record.developedLength),w=Number(record.developedWidth),reasons=[];let score=0,used=0;
    if(text){used++;const hit=`${record.code} ${record.name||''}`.toLowerCase().includes(text);score+=hit?1:0;reasons.push({feature:'text',state:hit?'OBSERVADO':'NO_OBSERVADO',weight:'experimental'});}
    if(ql!=null||qw!=null){used++;const direct=(ql==null?0:Math.abs(l-ql))+(qw==null?0:Math.abs(w-qw)),swap=(ql==null?0:Math.abs(w-ql))+(qw==null?0:Math.abs(l-qw)),distance=Math.min(direct,swap);const scale=Math.max(1,ql||0,qw||0);score+=Math.max(0,1-distance/scale);reasons.push({feature:'dimensions',state:finite(l)&&finite(w)?'OBSERVADO':'DESCONOCIDO',distanceMm:Number.isFinite(distance)?distance:null,orientation:swap<direct?'intercambiada':'directa'});}
    return {candidate,experimentalScore:used?score/used:null,reasons};
  }).sort((a,b)=>(b.experimentalScore??-1)-(a.experimentalScore??-1));
}

export function suggestNextAction(ranked){
  const active=ranked.filter(x=>(x.experimentalScore??0)>0).slice(0,50);
  if(!active.length)return {type:'request',prompt:'Introduce código, denominación o una medida fiable.',answers:['NO SE VE / NO ESTOY SEGURO']};
  if(active.length===1)return {type:'confirm',prompt:'Hay un candidato destacado. Confirma el código y el plano oficial.',answers:['CONFIRMAR','NO COINCIDE','NO ESTOY SEGURO']};
  return {type:'request',prompt:'Los candidatos restantes sólo tienen descriptores básicos. Añade una observación fiable; no se descartará por una ausencia dudosa.',answers:['AÑADIR MEDIDA','FOTOGRAFIAR ZONA','NO SE VE / NO ESTOY SEGURO']};
}
